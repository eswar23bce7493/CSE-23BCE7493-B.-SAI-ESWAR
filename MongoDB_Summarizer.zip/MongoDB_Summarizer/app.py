import warnings
warnings.filterwarnings("ignore")
import re

import logging
logging.getLogger("transformers").setLevel(logging.ERROR)

import streamlit as st
import tempfile

from document import read_docx, read_pdf_safe
from main_summarizer import summarize
from memory import save_memory, load_memory
from table_parser import format_timetable, make_readable
from ocr import image_to_text_from_bytes
from voice_handler import process_audio
from excel_reader import read_excel
from ppt_reader import read_ppt

# Page config
st.set_page_config(page_title="MongoDB Summarizer", page_icon="🤖")

st.title("✨ MongoDB Summarizer")
st.write("Summarize Text, Docs, Images, Excel, PPT and Voice with AI")

option = st.selectbox(
    "Choose Input Type",
    ["Enter Text", "Upload File", "Camera", "Voice"]
)

text = ""

# ---------------- TEXT ----------------
if option == "Enter Text":
    text = st.text_area("Enter your text:", height=200)

# ---------------- UNIVERSAL UPLOAD ----------------
elif option == "Upload File":
    uploaded_file = st.file_uploader(
        "Upload a document, spreadsheet, presentation, or image", 
        type=["pdf", "docx", "txt", "png", "jpg", "jpeg", "xlsx", "xls", "pptx", "ppt"]
    )

    if uploaded_file:
        ext = uploaded_file.name.split('.')[-1].lower()

        # PDF Branch
        if ext == "pdf":
            try:
                with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
                    tmp.write(uploaded_file.read())
                    temp_path = tmp.name

                text = read_pdf_safe(temp_path)
                if not text or len(text.strip()) < 20:
                    st.info("Scanner mode active. Text is sparse.")
                st.success("PDF processed successfully!")
            except Exception as e:
                st.error(f"Error processing PDF: {e}")

        # DOCX Branch
        elif ext == "docx":
            try:
                text = read_docx(uploaded_file)
                st.success("DOCX loaded successfully!")
            except Exception as e:
                st.error(f"Error reading DOCX: {e}")

        # EXCEL Branch
        elif ext in ["xlsx", "xls"]:
            try:
                text = read_excel(uploaded_file)
                st.success("Excel data extracted successfully!")
            except Exception as e:
                st.error(f"Error reading Excel: {e}")

        # PPT Branch
        elif ext in ["pptx", "ppt"]:
            try:
                text = read_ppt(uploaded_file)
                st.success("PowerPoint text extracted successfully!")
            except Exception as e:
                st.error(f"Error reading PPT: {e}")

        # IMAGE Branch
        elif ext in ["png", "jpg", "jpeg"]:
            st.image(uploaded_file)
            try:
                uploaded_file.seek(0)
                bytes_data = uploaded_file.read()
                text = image_to_text_from_bytes(bytes_data)
                st.success("Image processed successfully!")
            except Exception as e:
                st.error(f"Error processing Image: {e}")
                
        # TXT Branch
        elif ext == "txt":
            try:
                text = uploaded_file.read().decode("utf-8")
                st.success("Text file loaded!")
            except Exception as e:
                st.error(f"Error reading text file: {e}")

        if text:
            st.write("Extracted length:", len(text))

# ---------------- CAMERA ----------------
elif option == "Camera":
    camera_img = st.camera_input("Take a picture")

    if camera_img:
        try:
            camera_img.seek(0)
            bytes_data = camera_img.read()
            text = image_to_text_from_bytes(bytes_data)
            st.success("Camera image processed!")
        except Exception as e:
            st.error(f"Error with Camera capturing: {e}")

# ---------------- VOICE ----------------
elif option == "Voice":
    if hasattr(st, "audio_input"):
        audio_file = st.audio_input("Record your voice")

        if audio_file:
            try:
                audio_file.seek(0)
                text = process_audio(audio_file)
                st.success("Voice converted to text!")
            except Exception as e:
                st.error(f"Error converting Voice: {e}")
    else:
        st.error("Update Streamlit for voice feature")

# ---------------- CLEAN AND SHOW TEXT ----------------
if text:
    try:
        # Fix the issue where PyPDF or other extractors put each word/phrase on a new line
        text = re.sub(r'\n+', ' ', text)
        text = re.sub(r'\s+', ' ', text).strip()

        st.subheader("Extracted Text (Preview)")
        preview_sentences = re.split(r'(?<=[.!?])\s+', text[:1000])
        preview_sentences = [s.strip() for s in preview_sentences if s.strip()]
        for s in preview_sentences:
            st.write(s)
    except Exception as e:
        st.error(f"Error processing text preview: {e}")

# ---------------- SUMMARIZE ----------------
if st.button("🚀 Summarize"):
    if text and len(text.strip()) > 10:
        try:
            structured = format_timetable(text)
            readable = make_readable(structured)

            if readable and len(readable.strip()) > 20:
                st.subheader("Structured Timetable")
                st.write(readable)
                summary_input = readable
            else:
                summary_input = text
        except Exception as e:
            st.error(f"Error during structuring phase: {e}")
            summary_input = text

        try:
            summary = summarize(summary_input)

            st.subheader("AI Summary")
            # Split into sentences and display line by line
            sentences = re.split(r'(?<=[.!?])\s+', summary.strip())
            sentences = [s.strip() for s in sentences if s.strip()]
            for sentence in sentences:
                st.markdown(f"- {sentence}")

            save_memory(text, summary)
        except Exception as e:
            st.error(f"Error generating summary: {e}")

    else:
        st.warning("No readable text found")

# ---------------- HISTORY ----------------
if st.checkbox("Show History"):
    try:
        from memory import update_memory, delete_memory, clear_all_memory
        
        history = load_memory()

        if not history:
            st.info("No history found.")
        else:
            if st.button("🗑 Clear All History", key="clear_all"):
                clear_all_memory()
                st.success("History cleared!")
                st.rerun()

            for idx, item in enumerate(history):
                item_id = item.get("id")
                # Expandable container for each history item
                with st.expander(f"History Item #{idx + 1} - {item['input'][:40]}...", expanded=False):
                    st.write("**Original Input:**")
                    st.write(item["input"])
                    st.write("**Summary:**")
                    st.write(item["summary"])
                    
                    edit_key = f"edit_mode_{item_id}_{idx}"
                    if edit_key not in st.session_state:
                        st.session_state[edit_key] = False

                    col1, col2 = st.columns(2)
                    with col1:
                        if st.button("📝 Edit", key=f"edit_{item_id}_{idx}"):
                            st.session_state[edit_key] = not st.session_state[edit_key]
                            st.rerun()
                    with col2:
                        if st.button("❌ Delete", key=f"delete_{item_id}_{idx}"):
                            delete_memory(item_id)
                            st.success("Item deleted!")
                            st.rerun()

                    if st.session_state[edit_key]:
                        new_input = st.text_area("Edit Input:", value=item["input"], key=f"inp_{item_id}_{idx}", height=100)
                        new_summary = st.text_area("Edit Summary:", value=item["summary"], key=f"sum_{item_id}_{idx}", height=100)
                        if st.button("💾 Save Changes", key=f"save_{item_id}_{idx}"):
                            update_memory(item_id, new_input, new_summary)
                            st.session_state[edit_key] = False
                            st.success("Item updated!")
                            st.rerun()
    except Exception as e:
        st.error(f"Error loading history: {e}")