import speech_recognition as sr
import tempfile
import os

def process_audio(audio_file_like) -> str:
    """Read a streamlit audio uploaded file (or captured) and return text."""
    recognizer = sr.Recognizer()
    
    # Save the audio as a temporary file since speech_recognition needs a file path/audio file
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as temp_audio:
        temp_audio.write(audio_file_like.read())
        temp_audio_path = temp_audio.name
        
    try:
        # Pydub might be needed to convert to wav if it's not wav, but st.audio_input returns .wav usually.
        with sr.AudioFile(temp_audio_path) as source:
            # Listen to the audio file
            audio_data = recognizer.record(source)
            # Recognize speech
            text = recognizer.recognize_google(audio_data)
        return text
    except sr.UnknownValueError:
        return "Could not understand audio"
    except sr.RequestError as e:
        return f"Could not request results from Google Speech Recognition service; {e}"
    except Exception as e:
        return f"Error processing audio: {e}"
    finally:
        if os.path.exists(temp_audio_path):
            os.remove(temp_audio_path)
