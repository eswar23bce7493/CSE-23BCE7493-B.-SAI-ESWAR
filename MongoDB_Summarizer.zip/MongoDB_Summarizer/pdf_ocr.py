import fitz  # PyMuPDF
import easyocr
import numpy as np
from ocr import preprocess_image

# Lazy reader — initialized on first use
_reader = None

def _get_reader():
    global _reader
    if _reader is None:
        _reader = easyocr.Reader(['en'], gpu=False)
    return _reader


def pdf_to_text_ocr(file_path):
    text = ""
    doc = fitz.open(file_path)

    for page in doc:
        # Render page to an image
        pix = page.get_pixmap(dpi=150)

        # Convert to numpy array for EasyOCR
        img_array = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.h, pix.w, pix.n)

        try:
            import cv2
            # PyMuPDF yields RGB/RGBA, so we convert it to BGR/BGRA for consistent CV2 processing
            if pix.n == 4:
                img_array = cv2.cvtColor(img_array, cv2.COLOR_RGBA2BGRA)
            elif pix.n == 3:
                img_array = cv2.cvtColor(img_array, cv2.COLOR_RGB2BGR)
                
            img_array = preprocess_image(img_array)
        except ImportError:
            # Fallback if no OpenCV
            pass

        extracted = _get_reader().readtext(img_array, detail=0)
        text += " ".join(extracted) + " "

    return text
