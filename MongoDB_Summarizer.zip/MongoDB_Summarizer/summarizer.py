try:
    from transformers import pipeline
except ImportError:
    pipeline = None

summarizer = None


def get_summarizer():
    global summarizer

    if summarizer is None:
        if pipeline is None:
            raise ImportError(
                "transformers is required for online summarization. "
                "Install it with: pip install transformers torch"
            )
        summarizer = pipeline("summarization", model="facebook/bart-large-cnn")

    return summarizer

def summarize_text(text):
    model = get_summarizer()
    max_chunk = 500
    chunks = [text[i:i+max_chunk] for i in range(0, len(text), max_chunk)]
    
    final_summary = ""

    for chunk in chunks:
        result = model(chunk, max_length=100, min_length=30, do_sample=False)
        final_summary += result[0]['summary_text'] + " "

    return final_summary.strip()
