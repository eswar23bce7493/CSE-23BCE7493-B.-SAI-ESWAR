import os
import json
import datetime
import uuid
from pathlib import Path
from bson import ObjectId
from pymongo import MongoClient
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017/")
DB_NAME = os.getenv("MONGO_DB_NAME", "ai_chatbot_db")
COLLECTION_NAME = os.getenv("MONGO_COLLECTION_NAME", "chat_history")

# Initialize client
client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000)
db = client[DB_NAME]
collection = db[COLLECTION_NAME]

FILE = Path(__file__).with_name("memory.json")

def migrate_to_mongodb():
    """Migrates history from local memory.json to MongoDB if it exists."""
    if FILE.exists():
        try:
            with open(FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            if data and isinstance(data, list):
                # Add timestamp to migrated data
                timestamp = datetime.datetime.now(datetime.timezone.utc)
                inserted_count = 0
                for item in data:
                    if "input" in item and "summary" in item:
                        # Check if already exists to avoid duplicates
                        if not collection.find_one({"input": item["input"], "summary": item["summary"]}):
                            collection.insert_one({
                                "input": item["input"],
                                "summary": item["summary"],
                                "timestamp": timestamp
                            })
                            inserted_count += 1
                print(f"Successfully migrated {inserted_count} items from memory.json to MongoDB database.")
            # Backup the file instead of deleting to prevent data loss
            FILE.rename(FILE.with_name("memory.json.bak"))
        except Exception as e:
            print(f"Error during MongoDB migration: {e}")

# Run migration check on import
try:
    migrate_to_mongodb()
except Exception as e:
    print(f"Could not run migration: {e}")

def save_memory(input_text, summary):
    """CREATE operation: Saves a history record."""
    try:
        doc = {
            "input": input_text,
            "summary": summary,
            "timestamp": datetime.datetime.now(datetime.timezone.utc)
        }
        collection.insert_one(doc)
        print("Saved chat entry to MongoDB.")
    except Exception as e:
        print(f"Error saving to MongoDB: {e}")
        # Fallback to local file if MongoDB is not accessible
        save_fallback(input_text, summary)

def save_fallback(input_text, summary):
    fallback_file = Path(__file__).with_name("memory_fallback.json")
    try:
        if fallback_file.exists():
            with open(fallback_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        else:
            data = []
    except Exception:
        data = []
    
    data.append({
        "id": str(uuid.uuid4()),
        "input": input_text, 
        "summary": summary, 
        "timestamp": str(datetime.datetime.now(datetime.timezone.utc))
    })
    
    try:
        with open(fallback_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4)
        print("Saved chat to local fallback file memory_fallback.json.")
    except Exception as e:
        print(f"Failed to write to fallback: {e}")

def load_memory():
    """READ operation: Retrieves all history records."""
    try:
        # Check connection first
        client.admin.command('ping')
        cursor = collection.find().sort("timestamp", 1) # chronological order
        history = []
        for doc in cursor:
            history.append({
                "id": str(doc.get("_id")),
                "input": doc.get("input"),
                "summary": doc.get("summary")
            })
        return history
    except Exception as e:
        print(f"Error loading from MongoDB: {e}")
        # Fallback to local files
        history = []
        for fn in ["memory_fallback.json", "memory.json.bak", "memory.json"]:
            fallback_file = Path(__file__).with_name(fn)
            if fallback_file.exists():
                try:
                    with open(fallback_file, "r", encoding="utf-8") as f:
                        file_data = json.load(f)
                        if isinstance(file_data, list):
                            for idx, item in enumerate(file_data):
                                # Ensure item has an ID (generate a deterministic or random one if missing)
                                if "id" not in item:
                                    item["id"] = f"local-{fn}-{idx}"
                                history.append({
                                    "id": item.get("id"),
                                    "input": item.get("input"),
                                    "summary": item.get("summary")
                                })
                except Exception:
                    pass
        return history

def update_memory(item_id, new_input, new_summary):
    """UPDATE operation: Modifies an existing history record by ID."""
    try:
        # Check connection first
        client.admin.command('ping')
        # Check if ID is a valid ObjectId (since MongoDB _ids are ObjectIds)
        if ObjectId.is_valid(item_id):
            result = collection.update_one(
                {"_id": ObjectId(item_id)},
                {"$set": {"input": new_input, "summary": new_summary}}
            )
            if result.modified_count > 0:
                print(f"Successfully updated record {item_id} in MongoDB.")
                return True
        print(f"Record {item_id} not updated in MongoDB (or is a local fallback ID). Trying fallback update.")
        return update_fallback(item_id, new_input, new_summary)
    except Exception as e:
        print(f"Error updating MongoDB: {e}. Trying fallback update.")
        return update_fallback(item_id, new_input, new_summary)

def update_fallback(item_id, new_input, new_summary):
    updated = False
    for fn in ["memory_fallback.json", "memory.json.bak", "memory.json"]:
        fallback_file = Path(__file__).with_name(fn)
        if fallback_file.exists():
            try:
                with open(fallback_file, "r", encoding="utf-8") as f:
                    file_data = json.load(f)
                if isinstance(file_data, list):
                    modified = False
                    for idx, item in enumerate(file_data):
                        # Ensure item has an ID to compare
                        current_id = item.get("id", f"local-{fn}-{idx}")
                        if current_id == item_id:
                            item["input"] = new_input
                            item["summary"] = new_summary
                            item["id"] = current_id # persist the ID
                            modified = True
                            updated = True
                    if modified:
                        with open(fallback_file, "w", encoding="utf-8") as f:
                            json.dump(file_data, f, indent=4)
                        print(f"Successfully updated record {item_id} in local file {fn}.")
            except Exception as e:
                print(f"Failed to update in {fn}: {e}")
    return updated

def delete_memory(item_id):
    """DELETE operation: Deletes a specific history record by ID."""
    try:
        # Check connection first
        client.admin.command('ping')
        if ObjectId.is_valid(item_id):
            result = collection.delete_one({"_id": ObjectId(item_id)})
            if result.deleted_count > 0:
                print(f"Successfully deleted record {item_id} from MongoDB.")
                return True
        print(f"Record {item_id} not deleted from MongoDB (or is a local fallback ID). Trying fallback delete.")
        return delete_fallback(item_id)
    except Exception as e:
        print(f"Error deleting from MongoDB: {e}. Trying fallback delete.")
        return delete_fallback(item_id)

def delete_fallback(item_id):
    deleted = False
    for fn in ["memory_fallback.json", "memory.json.bak", "memory.json"]:
        fallback_file = Path(__file__).with_name(fn)
        if fallback_file.exists():
            try:
                with open(fallback_file, "r", encoding="utf-8") as f:
                    file_data = json.load(f)
                if isinstance(file_data, list):
                    original_len = len(file_data)
                    new_file_data = []
                    for idx, item in enumerate(file_data):
                        current_id = item.get("id", f"local-{fn}-{idx}")
                        if current_id != item_id:
                            # Retain the item
                            if "id" not in item:
                                item["id"] = current_id
                            new_file_data.append(item)
                    if len(new_file_data) < original_len:
                        with open(fallback_file, "w", encoding="utf-8") as f:
                            json.dump(new_file_data, f, indent=4)
                        print(f"Successfully deleted record {item_id} from local file {fn}.")
                        deleted = True
            except Exception as e:
                print(f"Failed to delete in {fn}: {e}")
    return deleted

def clear_all_memory():
    """DELETE ALL operation: Clears all history from MongoDB and fallback files."""
    try:
        # Check connection first
        client.admin.command('ping')
        collection.delete_many({})
        print("Cleared all records in MongoDB chat history.")
    except Exception as e:
        print(f"Error clearing MongoDB collection: {e}")
    
    # Also clear local fallback files
    for fn in ["memory_fallback.json", "memory.json.bak", "memory.json"]:
        fallback_file = Path(__file__).with_name(fn)
        if fallback_file.exists():
            try:
                with open(fallback_file, "w", encoding="utf-8") as f:
                    json.dump([], f, indent=4)
                print(f"Cleared all records in local file {fn}.")
            except Exception as e:
                print(f"Failed to clear {fn}: {e}")
