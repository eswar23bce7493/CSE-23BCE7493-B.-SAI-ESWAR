from summarizer import summarize_text
from offline_model import summarize_offline
from network import is_online

def summarize(text):
    if is_online():
        try:
            return summarize_text(text)
        except Exception:
            return summarize_offline(text)

    return summarize_offline(text)
