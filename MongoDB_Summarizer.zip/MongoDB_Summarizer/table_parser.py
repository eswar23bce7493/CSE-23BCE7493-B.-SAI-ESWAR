import re

# Clean OCR text
def clean_text(text):
    text = text.replace("|", " ")
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"\n{2,}", "\n", text)

    cleaned_lines = []
    for line in text.split("\n"):
        line = re.sub(r"\s+", " ", line).strip()
        if line:
            cleaned_lines.append(line)

    return "\n".join(cleaned_lines)


def extract_details(line):
    # Time pattern (08:00–09:00, 8:00 AM - 9:00 PM etc.)
    time_match = re.search(r'(?i)\d{1,2}:\d{2}\s*(?:AM|PM)?\s*[-–]\s*\d{1,2}:\d{2}\s*(?:AM|PM)?', line)

    # Room pattern (Room A101, Lab-2, ETH-512, B-12 etc.)
    room_match = re.search(r'(?i)\b(?:Room\s+|Lab-?|Bldg\s+)?[a-zA-Z]{1,5}-?\d{1,4}\b', line)

    # Subject (remove time & room from line)
    subject = line
    if time_match:
        subject = subject.replace(time_match.group(), "")
    if room_match:
        subject = subject.replace(room_match.group(), "")

    subject = subject.strip()

    return {
        "time": time_match.group() if time_match else "N/A",
        "room": room_match.group() if room_match else "N/A",
        "subject": subject
    }


def format_timetable(text):
    text = clean_text(text)

    lines = text.split("\n")
    result = {}

    current_day = None
    days_map = {
        "MONDAY": "MON", "MON": "MON",
        "TUESDAY": "TUE", "TUE": "TUE",
        "WEDNESDAY": "WED", "WED": "WED",
        "THURSDAY": "THU", "THU": "THU",
        "FRIDAY": "FRI", "FRI": "FRI",
        "SATURDAY": "SAT", "SAT": "SAT",
        "SUNDAY": "SUN", "SUN": "SUN"
    }

    for line in lines:
        line = line.strip()

        if len(line) < 5:
            continue

        upper_line = line.upper()
        matched_day = None
        for day_word, day_key in days_map.items():
            if re.search(rf'\b{day_word}\b', upper_line):
                matched_day = day_key
                break

        if matched_day:
            current_day = matched_day
            if current_day not in result:
                result[current_day] = []
        elif current_day:
            details = extract_details(line)
            result[current_day].append(details)

    return result


def make_readable(data):
    output = ""

    for day, items in data.items():
        output += f"\n📅 {day}:\n"

        for item in items:
            if item['subject'] and item['subject'] != "N/A":
                output += f"- {item['time']} → {item['subject']} → Room {item['room']}\n"

    return output
