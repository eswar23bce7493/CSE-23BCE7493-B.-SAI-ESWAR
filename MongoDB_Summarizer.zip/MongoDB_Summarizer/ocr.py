import easyocr
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None

# Lazy reader — initialized on first use to avoid blocking imports
_reader = None

def _get_reader():
    global _reader
    if _reader is None:
        _reader = easyocr.Reader(['en'], gpu=False)
    return _reader

def preprocess_image(img):
    if cv2 is None:
        return img
    
    # Check if already grayscale via dimension length
    if len(img.shape) == 3 and img.shape[2] >= 3:
        # If RGBA, we convert to BGR first or directly GRAY
        if img.shape[2] == 4:
            img = cv2.cvtColor(img, cv2.COLOR_BGRA2GRAY)
        else:
            img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    # Upscale
    img = cv2.resize(img, None, fx=1.5, fy=1.5, interpolation=cv2.INTER_CUBIC)
    
    # Adaptive Thresholding for improved text boundary capture against noise
    img = cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 11, 2)
    return img

def image_to_text(path):
    if cv2 is not None:
        img = cv2.imread(path)
        if img is not None:
            img = preprocess_image(img)
            result = _get_reader().readtext(img, detail=0)
            return " ".join(result)
    
    # Fallback to basic load if cv2 lacks or fails
    result = _get_reader().readtext(path, detail=0)
    return " ".join(result)


def image_to_text_from_bytes(file_bytes):
    if cv2 is None:
        return "OpenCV not installed. Please install opencv-python."

    # Convert bytes → numpy array
    nparr = np.frombuffer(file_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    if img is None:
        return "Error decoding image"

    img = preprocess_image(img)
    result = _get_reader().readtext(img, detail=0)
    return " ".join(result)