import heapq
import re

def summarize_offline(text, n=2):
    sentences = re.split(r'(?<=[.!?]) +', text)
    
    scores = {}
    for sentence in sentences:
        scores[sentence] = len(sentence.split())
    
    top_sentences = heapq.nlargest(n, scores, key=scores.get)
    
    return " ".join(top_sentences)