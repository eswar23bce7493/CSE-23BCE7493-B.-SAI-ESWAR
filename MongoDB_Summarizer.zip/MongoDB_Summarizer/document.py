import importlib

# Handle PDF
try:
    PdfReader = importlib.import_module("PyPDF2").PdfReader
except ImportError:
    PdfReader = importlib.import_module("pypdf").PdfReader

# Handle DOCX
try:
    import docx
except ImportError:
    docx = None


def read_pdf(file):
    reader = PdfReader(file)
    text = ""

    for page in reader.pages:
        content = page.extract_text()
        if content:  # ✅ avoid None error
            text += content + "\n"

    return text.strip()


def read_docx(file):
    if docx is None:
        raise ImportError("python-docx is required to read DOCX files")

    doc = docx.Document(file)
    return "\n".join([p.text for p in doc.paragraphs if p.text])

def read_pdf_safe(file_path):
    try:
        text = read_pdf(file_path)
        
        # If very small → likely scanned
        if len(text.strip()) < 50:
            from pdf_ocr import pdf_to_text_ocr
            text = pdf_to_text_ocr(file_path)
        
        return text
    
    except:
        from pdf_ocr import pdf_to_text_ocr
        return pdf_to_text_ocr(file_path)